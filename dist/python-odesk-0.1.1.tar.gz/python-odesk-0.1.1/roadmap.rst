.. _roadmap:


***************
Roadmap
***************

.. 

.. _0.2:

Version 0.2
-----------------
*August 2010*

Session based client for authentication with username and password for background tasks


.. _0.3:

Version 0.3
-----------------
*October 2010*



.. _0.4:

Version 0.4
-----------------







